import { Link } from 'wouter';
import { motorcycles } from '@/lib/motorcycles';
import MotorcycleCard from '@/components/MotorcycleCard';
import { Zap, Shield, Gauge } from 'lucide-react';

export default function Home() {
  const featuredMotorcycles = motorcycles.slice(0, 3);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen md:h-[80vh] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/hero-moto-trilha-QkfTT7Lhw6tf9eUWCaVEfE.webp)',
            backgroundAttachment: 'fixed',
          }}
        >
          <div className="absolute inset-0 bg-black/50" />
        </div>

        {/* Hero Content */}
        <div className="relative h-full flex items-center">
          <div className="container">
            <div className="max-w-2xl space-y-6 animate-slide-in-up">
              <div className="action-badge">
                <Zap className="w-4 h-4" />
                Aventura Extrema
              </div>
              <h1 className="display-title text-5xl md:text-7xl text-white glow-text">
                CONQUER
                <br />
                THE TRAILS
              </h1>
              <p className="text-lg md:text-xl text-gray-200 max-w-xl leading-relaxed">
                Descubra as motos de trilha mais potentes e confiáveis do mercado. Equipamento profissional para aventureiros que não têm medo de desafios.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link href="/motos">
                  <button className="px-8 py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-300 transform hover:scale-105 shadow-lg shadow-primary/50">
                    Ver Catálogo
                  </button>
                </Link>
                <Link href="/buscar">
                  <button className="px-8 py-3 bg-transparent border-2 border-primary text-primary font-bold rounded-lg hover:bg-primary hover:text-primary-foreground transition-all duration-300">
                    Buscar Moto
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-secondary">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-4 text-center group">
              <div className="w-16 h-16 mx-auto bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 group-hover:bg-accent transition-all duration-300">
                <Zap className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Alta Performance</h3>
              <p className="text-muted-foreground">
                Motores potentes e suspensão de classe mundial para máximo desempenho em qualquer terreno.
              </p>
            </div>

            <div className="space-y-4 text-center group">
              <div className="w-16 h-16 mx-auto bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 group-hover:bg-accent transition-all duration-300">
                <Shield className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Segurança Garantida</h3>
              <p className="text-muted-foreground">
                Sistemas de frenagem avançados e estrutura reforçada para sua proteção total.
              </p>
            </div>

            <div className="space-y-4 text-center group">
              <div className="w-16 h-16 mx-auto bg-primary rounded-lg flex items-center justify-center group-hover:scale-110 group-hover:bg-accent transition-all duration-300">
                <Gauge className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Controle Total</h3>
              <p className="text-muted-foreground">
                Direção precisa e responsiva para dominar as trilhas mais desafiadoras.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Motorcycles */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container space-y-12">
          <div className="space-y-4 text-center">
            <div className="action-badge justify-center">
              <Zap className="w-4 h-4" />
              Destaque
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground">
              Motos em Destaque
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Conheça os modelos mais procurados e admirados por pilotos profissionais e entusiastas.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {featuredMotorcycles.map((moto) => (
              <MotorcycleCard key={moto.id} motorcycle={moto} />
            ))}
          </div>

          <div className="text-center pt-8">
            <Link href="/motos">
              <button className="px-8 py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-300 transform hover:scale-105">
                Ver Todos os Modelos
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/trail-landscape-SvBqLTkCPAAdF684CLpsLf.webp)',
            backgroundAttachment: 'fixed',
          }}
        >
          <div className="absolute inset-0 bg-black/60" />
        </div>

        <div className="relative container text-center space-y-8 max-w-2xl mx-auto">
          <h2 className="display-title text-4xl md:text-5xl text-white glow-text">
            Pronto para a Aventura?
          </h2>
          <p className="text-lg text-gray-200">
            Explore nosso catálogo completo e encontre a moto perfeita para suas trilhas.
          </p>
          <Link href="/motos">
            <button className="px-10 py-4 bg-primary text-primary-foreground font-bold text-lg rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-300 transform hover:scale-105 shadow-lg shadow-primary/50">
              Explorar Catálogo
            </button>
          </Link>
        </div>
      </section>
    </div>
  );
}
