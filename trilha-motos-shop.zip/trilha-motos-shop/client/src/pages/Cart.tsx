import { useCart } from '@/contexts/CartContext';
import { Link } from 'wouter';
import { Trash2, ArrowLeft, ShoppingCart } from 'lucide-react';
import { useState } from 'react';

export default function Cart() {
  const { items, removeFromCart, updateQuantity, getTotalPrice, clearCart } = useCart();
  const [orderPlaced, setOrderPlaced] = useState(false);
  const totalPrice = getTotalPrice();

  const handleCheckout = () => {
    setOrderPlaced(true);
    setTimeout(() => {
      clearCart();
      setOrderPlaced(false);
    }, 2000);
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-6 animate-slide-in-up">
          <div className="w-20 h-20 mx-auto bg-accent rounded-full flex items-center justify-center">
            <ShoppingCart className="w-10 h-10 text-accent-foreground" />
          </div>
          <h1 className="text-4xl font-bold text-foreground">Compra Confirmada!</h1>
          <p className="text-lg text-muted-foreground max-w-md mx-auto">
            Obrigado pela sua compra. Você receberá um e-mail de confirmação em breve com os detalhes do seu pedido.
          </p>
          <Link href="/">
            <button className="px-8 py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent transition-all">
              Voltar ao Início
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-secondary border-b border-border py-8">
        <div className="container">
          <Link href="/motos" className="flex items-center gap-2 text-primary hover:text-accent transition-colors mb-4 w-fit">
            <ArrowLeft className="w-5 h-5" />
            Continuar Comprando
          </Link>
          <h1 className="text-4xl font-bold text-foreground">Seu Carrinho</h1>
        </div>
      </section>

      {/* Content */}
      <section className="py-12">
        <div className="container">
          {items.length === 0 ? (
            <div className="text-center py-16 space-y-6">
              <ShoppingCart className="w-20 h-20 mx-auto text-muted-foreground opacity-50" />
              <div className="space-y-2">
                <h2 className="text-3xl font-bold text-foreground">Carrinho Vazio</h2>
                <p className="text-muted-foreground text-lg">
                  Você ainda não adicionou nenhuma moto ao carrinho.
                </p>
              </div>
              <Link href="/motos">
                <button className="px-8 py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent transition-all">
                  Explorar Catálogo
                </button>
              </Link>
            </div>
          ) : (
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                {items.map((item, index) => (
                  <div
                    key={item.motorcycle.id}
                    className="bg-card border border-border rounded-lg p-6 flex gap-6 animate-slide-in-up"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    {/* Image */}
                    <div className="w-32 h-32 flex-shrink-0 rounded-lg overflow-hidden bg-secondary">
                      <img
                        src={item.motorcycle.image}
                        alt={`${item.motorcycle.brand} ${item.motorcycle.model}`}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 space-y-4">
                      <div>
                        <h3 className="text-xl font-bold text-foreground">
                          {item.motorcycle.brand} {item.motorcycle.model}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          Modelo {item.motorcycle.year}
                        </p>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center border border-border rounded-lg">
                          <button
                            onClick={() => updateQuantity(item.motorcycle.id, item.quantity - 1)}
                            className="px-3 py-1 text-foreground hover:bg-secondary transition-colors"
                          >
                            −
                          </button>
                          <span className="px-4 py-1 font-semibold text-foreground">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.motorcycle.id, item.quantity + 1)}
                            className="px-3 py-1 text-foreground hover:bg-secondary transition-colors"
                          >
                            +
                          </button>
                        </div>

                        <div className="text-right">
                          <p className="text-sm text-muted-foreground mb-1">Subtotal</p>
                          <p className="price-text text-2xl text-primary">
                            R$ {(item.motorcycle.price * item.quantity).toLocaleString('pt-BR')}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Remove Button */}
                    <button
                      onClick={() => removeFromCart(item.motorcycle.id)}
                      className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="lg:col-span-1">
                <div className="bg-card border border-border rounded-lg p-8 space-y-6 sticky top-24 animate-slide-in-down">
                  <h2 className="text-2xl font-bold text-foreground">Resumo do Pedido</h2>

                  <div className="space-y-3 py-6 border-y border-border">
                    <div className="flex justify-between text-foreground">
                      <span>Subtotal ({items.length} item{items.length !== 1 ? 's' : ''})</span>
                      <span className="price-text">R$ {totalPrice.toLocaleString('pt-BR')}</span>
                    </div>
                    <div className="flex justify-between text-foreground">
                      <span>Frete</span>
                      <span className="price-text text-accent">Grátis</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-foreground">Total</span>
                    <p className="price-text text-3xl text-primary">
                      R$ {totalPrice.toLocaleString('pt-BR')}
                    </p>
                  </div>

                  <button
                    onClick={handleCheckout}
                    className="w-full py-4 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-300 transform hover:scale-105 shadow-lg shadow-primary/50"
                  >
                    Finalizar Compra
                  </button>

                  <button
                    onClick={() => clearCart()}
                    className="w-full py-2 text-destructive font-medium hover:bg-destructive/10 rounded-lg transition-colors"
                  >
                    Limpar Carrinho
                  </button>

                  <Link href="/motos">
                    <button className="w-full py-2 text-primary font-medium hover:bg-primary/10 rounded-lg transition-colors">
                      Continuar Comprando
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
