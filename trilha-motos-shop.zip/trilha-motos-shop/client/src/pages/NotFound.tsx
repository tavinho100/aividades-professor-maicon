import { Link } from 'wouter';
import { AlertCircle } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center space-y-6 px-4">
        <AlertCircle className="w-20 h-20 mx-auto text-primary" />
        <div className="space-y-2">
          <h1 className="display-title text-6xl text-primary">404</h1>
          <h2 className="text-3xl font-bold text-foreground">Página não encontrada</h2>
          <p className="text-lg text-muted-foreground max-w-md mx-auto">
            Desculpe, a página que você está procurando não existe ou foi movida.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
          <Link href="/">
            <button className="px-8 py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-300 transform hover:scale-105">
              Voltar ao Início
            </button>
          </Link>
          <Link href="/motos">
            <button className="px-8 py-3 bg-secondary text-foreground font-bold rounded-lg hover:bg-border transition-all duration-300">
              Ver Catálogo
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
