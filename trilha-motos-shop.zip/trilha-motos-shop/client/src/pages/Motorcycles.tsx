import { motorcycles } from '@/lib/motorcycles';
import MotorcycleCard from '@/components/MotorcycleCard';
import { useState } from 'react';
import { Filter } from 'lucide-react';

export default function Motorcycles() {
  const [sortBy, setSortBy] = useState<'price-asc' | 'price-desc' | 'name'>('name');

  const sortedMotorcycles = [...motorcycles].sort((a, b) => {
    switch (sortBy) {
      case 'price-asc':
        return a.price - b.price;
      case 'price-desc':
        return b.price - a.price;
      case 'name':
      default:
        return `${a.brand} ${a.model}`.localeCompare(`${b.brand} ${b.model}`);
    }
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-secondary border-b border-border py-12">
        <div className="container space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            Catálogo Completo
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Explore todos os modelos de motos de trilha disponíveis. Cada uma selecionada para oferecer o melhor desempenho e confiabilidade.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-12">
        <div className="container space-y-8">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-card p-6 rounded-lg border border-border">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-primary" />
              <span className="font-semibold text-foreground">Ordenar por:</span>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => setSortBy('name')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  sortBy === 'name'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-foreground hover:bg-border'
                }`}
              >
                Nome
              </button>
              <button
                onClick={() => setSortBy('price-asc')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  sortBy === 'price-asc'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-foreground hover:bg-border'
                }`}
              >
                Menor Preço
              </button>
              <button
                onClick={() => setSortBy('price-desc')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  sortBy === 'price-desc'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-foreground hover:bg-border'
                }`}
              >
                Maior Preço
              </button>
            </div>
          </div>

          {/* Motorcycles Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sortedMotorcycles.map((moto, index) => (
              <div key={moto.id} className="animate-slide-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                <MotorcycleCard motorcycle={moto} />
              </div>
            ))}
          </div>

          {/* Stats */}
          <div className="mt-16 pt-8 border-t border-border text-center space-y-4">
            <p className="text-lg font-semibold text-foreground">
              Total de {motorcycles.length} motos disponíveis
            </p>
            <p className="text-muted-foreground">
              Preço médio: R$ {(motorcycles.reduce((sum, m) => sum + m.price, 0) / motorcycles.length).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
