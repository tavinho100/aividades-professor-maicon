import { useState } from 'react';
import { motorcycles } from '@/lib/motorcycles';
import MotorcycleCard from '@/components/MotorcycleCard';
import { Search as SearchIcon } from 'lucide-react';

export default function Search() {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState(motorcycles);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    if (term.trim() === '') {
      setSearchResults(motorcycles);
    } else {
      const filtered = motorcycles.filter((moto) => {
        const searchLower = term.toLowerCase();
        return (
          moto.brand.toLowerCase().includes(searchLower) ||
          moto.model.toLowerCase().includes(searchLower) ||
          moto.description.toLowerCase().includes(searchLower)
        );
      });
      setSearchResults(filtered);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Search Header */}
      <section className="bg-secondary border-b border-border py-12">
        <div className="container space-y-8">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground">
              Buscar Moto
            </h1>
            <p className="text-lg text-muted-foreground">
              Encontre a moto perfeita para suas aventuras nas trilhas
            </p>
          </div>

          {/* Search Input */}
          <div className="relative">
            <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 text-primary" />
            <input
              type="text"
              placeholder="Buscar por marca, modelo ou características..."
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full pl-14 pr-6 py-4 bg-card border-2 border-primary rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent transition-colors"
            />
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="py-12">
        <div className="container space-y-8">
          {searchResults.length > 0 ? (
            <>
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-foreground">
                  {searchResults.length} resultado{searchResults.length !== 1 ? 's' : ''} encontrado{searchResults.length !== 1 ? 's' : ''}
                </h2>
                {searchTerm && (
                  <button
                    onClick={() => handleSearch('')}
                    className="text-primary hover:text-accent transition-colors font-medium"
                  >
                    Limpar busca
                  </button>
                )}
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {searchResults.map((moto, index) => (
                  <div key={moto.id} className="animate-slide-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                    <MotorcycleCard motorcycle={moto} />
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-16 space-y-4">
              <SearchIcon className="w-16 h-16 mx-auto text-muted-foreground opacity-50" />
              <h2 className="text-2xl font-bold text-foreground">
                Nenhuma moto encontrada
              </h2>
              <p className="text-muted-foreground max-w-md mx-auto">
                Não encontramos motos que correspondam a "{searchTerm}". Tente buscar por outra marca ou modelo.
              </p>
              <button
                onClick={() => handleSearch('')}
                className="px-6 py-2 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent transition-all inline-block mt-4"
              >
                Ver Todas as Motos
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
