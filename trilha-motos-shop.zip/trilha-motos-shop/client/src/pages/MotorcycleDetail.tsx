import { useParams, Link } from 'wouter';
import { motorcycles } from '@/lib/motorcycles';
import { useCart } from '@/contexts/CartContext';
import { useState } from 'react';
import { ShoppingCart, ArrowLeft, Check } from 'lucide-react';

export default function MotorcycleDetail() {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);

  const motorcycle = motorcycles.find((m) => m.id === parseInt(id || '0'));

  if (!motorcycle) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-3xl font-bold text-foreground">Moto não encontrada</h1>
          <Link href="/motos">
            <button className="px-6 py-2 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent transition-all">
              Voltar ao Catálogo
            </button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(motorcycle, quantity);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const relatedMotorcycles = motorcycles.filter((m) => m.id !== motorcycle.id).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <div className="bg-secondary border-b border-border">
        <div className="container py-4 flex items-center gap-2 text-sm">
          <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
            Início
          </Link>
          <span className="text-muted-foreground">/</span>
          <Link href="/motos" className="text-muted-foreground hover:text-primary transition-colors">
            Catálogo
          </Link>
          <span className="text-muted-foreground">/</span>
          <span className="text-foreground font-semibold">{motorcycle.brand} {motorcycle.model}</span>
        </div>
      </div>

      {/* Main Content */}
      <section className="py-12">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            {/* Image */}
            <div className="space-y-4 animate-slide-in-up">
              <div className="relative bg-secondary rounded-lg overflow-hidden h-96 md:h-[500px] border border-border">
                <img
                  src={motorcycle.image}
                  alt={`${motorcycle.brand} ${motorcycle.model}`}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Details */}
            <div className="space-y-8 animate-slide-in-down">
              {/* Header */}
              <div className="space-y-4">
                <div className="action-badge">
                  <span>Modelo {motorcycle.year}</span>
                </div>
                <h1 className="text-4xl md:text-5xl font-bold text-foreground">
                  {motorcycle.brand}
                  <br />
                  <span className="text-primary">{motorcycle.model}</span>
                </h1>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  {motorcycle.description}
                </p>
              </div>

              {/* Price */}
              <div className="space-y-2 py-6 border-y border-border">
                <p className="text-sm text-muted-foreground">Preço</p>
                <p className="price-text text-5xl text-primary">
                  R$ {motorcycle.price.toLocaleString('pt-BR')}
                </p>
              </div>

              {/* Specifications */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-foreground">Especificações</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-secondary p-4 rounded-lg border border-border">
                    <p className="text-xs text-muted-foreground mb-1">Motor</p>
                    <p className="font-semibold text-foreground">{motorcycle.specs.engine}</p>
                  </div>
                  <div className="bg-secondary p-4 rounded-lg border border-border">
                    <p className="text-xs text-muted-foreground mb-1">Transmissão</p>
                    <p className="font-semibold text-foreground">{motorcycle.specs.transmission}</p>
                  </div>
                  <div className="bg-secondary p-4 rounded-lg border border-border">
                    <p className="text-xs text-muted-foreground mb-1">Capacidade de Combustível</p>
                    <p className="font-semibold text-foreground">{motorcycle.specs.fuelCapacity}</p>
                  </div>
                  <div className="bg-secondary p-4 rounded-lg border border-border">
                    <p className="text-xs text-muted-foreground mb-1">Peso</p>
                    <p className="font-semibold text-foreground">{motorcycle.specs.weight}</p>
                  </div>
                  <div className="col-span-2 bg-secondary p-4 rounded-lg border border-border">
                    <p className="text-xs text-muted-foreground mb-1">Potência Máxima</p>
                    <p className="font-semibold text-foreground">{motorcycle.specs.maxPower}</p>
                  </div>
                </div>
              </div>

              {/* Add to Cart */}
              <div className="space-y-4 pt-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-border rounded-lg">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-4 py-2 text-foreground hover:bg-secondary transition-colors"
                    >
                      −
                    </button>
                    <span className="px-6 py-2 font-semibold text-foreground">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-4 py-2 text-foreground hover:bg-secondary transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>

                <button
                  onClick={handleAddToCart}
                  className={`w-full py-4 font-bold text-lg rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2 ${
                    addedToCart
                      ? 'bg-accent text-accent-foreground'
                      : 'bg-primary text-primary-foreground hover:bg-accent hover:text-accent-foreground'
                  }`}
                >
                  {addedToCart ? (
                    <>
                      <Check className="w-6 h-6" />
                      Adicionado ao Carrinho!
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-6 h-6" />
                      Adicionar ao Carrinho
                    </>
                  )}
                </button>

                <Link href="/carrinho">
                  <button className="w-full py-3 font-bold border-2 border-primary text-primary rounded-lg hover:bg-primary hover:text-primary-foreground transition-all duration-300">
                    Ir para Carrinho
                  </button>
                </Link>
              </div>
            </div>
          </div>

          {/* Related Motorcycles */}
          {relatedMotorcycles.length > 0 && (
            <div className="space-y-8 pt-16 border-t border-border">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold text-foreground">Motos Relacionadas</h2>
                <p className="text-muted-foreground">Confira outros modelos que podem interessar você</p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                {relatedMotorcycles.map((moto) => (
                  <Link key={moto.id} href={`/moto/${moto.id}`}>
                    <div className="group cursor-pointer bg-card rounded-lg overflow-hidden border border-border hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/20">
                      <div className="relative overflow-hidden bg-secondary h-64">
                        <img
                          src={moto.image}
                          alt={`${moto.brand} ${moto.model}`}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      </div>
                      <div className="p-6 space-y-3">
                        <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                          {moto.brand} {moto.model}
                        </h3>
                        <p className="price-text text-2xl text-primary">
                          R$ {moto.price.toLocaleString('pt-BR')}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
