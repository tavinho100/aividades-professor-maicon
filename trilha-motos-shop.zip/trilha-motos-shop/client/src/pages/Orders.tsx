import { useState } from 'react';
import { Package, Search as SearchIcon, ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';

interface OrderInfo {
  id: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  date: string;
  items: number;
  total: number;
}

const mockOrders: OrderInfo[] = [
  {
    id: 'PED12345',
    status: 'delivered',
    date: '2024-02-15',
    items: 1,
    total: 28000,
  },
  {
    id: 'PED12346',
    status: 'shipped',
    date: '2024-02-20',
    items: 2,
    total: 51500,
  },
  {
    id: 'PED12347',
    status: 'processing',
    date: '2024-02-25',
    items: 1,
    total: 22500,
  },
];

const statusConfig = {
  pending: { label: 'Pendente', color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
  processing: { label: 'Processando', color: 'text-blue-500', bg: 'bg-blue-500/10' },
  shipped: { label: 'Enviado', color: 'text-purple-500', bg: 'bg-purple-500/10' },
  delivered: { label: 'Entregue', color: 'text-accent', bg: 'bg-accent/10' },
};

export default function Orders() {
  const [searchTerm, setSearchTerm] = useState('');
  const [foundOrder, setFoundOrder] = useState<OrderInfo | null>(null);
  const [searched, setSearched] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    const order = mockOrders.find((o) => o.id.toLowerCase() === searchTerm.toLowerCase());
    setFoundOrder(order || null);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-secondary border-b border-border py-8">
        <div className="container">
          <Link href="/" className="flex items-center gap-2 text-primary hover:text-accent transition-colors mb-4 w-fit">
            <ArrowLeft className="w-5 h-5" />
            Voltar
          </Link>
          <h1 className="text-4xl font-bold text-foreground">Consultar Pedidos</h1>
          <p className="text-muted-foreground mt-2">
            Digite o número do seu pedido para acompanhar o status
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-12">
        <div className="container max-w-2xl">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="space-y-6 mb-12">
            <div className="relative">
              <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 text-primary" />
              <input
                type="text"
                placeholder="Digite o número do pedido (ex: PED12345)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-14 pr-6 py-4 bg-card border-2 border-primary rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent transition-colors"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-300 transform hover:scale-105"
            >
              Buscar Pedido
            </button>
          </form>

          {/* Results */}
          {searched && (
            <div className="space-y-6">
              {foundOrder ? (
                <div className="bg-card border-2 border-primary rounded-lg p-8 space-y-6 animate-slide-in-up">
                  {/* Order Header */}
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Número do Pedido</p>
                      <h2 className="text-3xl font-bold text-foreground">{foundOrder.id}</h2>
                    </div>
                    <div className={`px-4 py-2 rounded-lg font-semibold ${statusConfig[foundOrder.status].bg} ${statusConfig[foundOrder.status].color}`}>
                      {statusConfig[foundOrder.status].label}
                    </div>
                  </div>

                  {/* Order Details */}
                  <div className="grid md:grid-cols-3 gap-4 py-6 border-y border-border">
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Data do Pedido</p>
                      <p className="font-semibold text-foreground">
                        {new Date(foundOrder.date).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Quantidade de Itens</p>
                      <p className="font-semibold text-foreground">{foundOrder.items}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Valor Total</p>
                      <p className="price-text text-xl text-primary">
                        R$ {foundOrder.total.toLocaleString('pt-BR')}
                      </p>
                    </div>
                  </div>

                  {/* Status Timeline */}
                  <div className="space-y-4">
                    <h3 className="font-bold text-foreground">Acompanhamento</h3>
                    <div className="space-y-3">
                      {[
                        { step: 'Pedido Confirmado', active: true },
                        { step: 'Processando', active: ['processing', 'shipped', 'delivered'].includes(foundOrder.status) },
                        { step: 'Enviado', active: ['shipped', 'delivered'].includes(foundOrder.status) },
                        { step: 'Entregue', active: foundOrder.status === 'delivered' },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center gap-4">
                          <div
                            className={`w-4 h-4 rounded-full ${
                              item.active ? 'bg-accent' : 'bg-border'
                            } transition-colors`}
                          />
                          <span className={item.active ? 'text-foreground font-semibold' : 'text-muted-foreground'}>
                            {item.step}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Message */}
                  <div className="bg-secondary p-4 rounded-lg border border-border">
                    <p className="text-sm text-muted-foreground">
                      {foundOrder.status === 'delivered' &&
                        'Seu pedido foi entregue com sucesso! Obrigado pela sua compra.'}
                      {foundOrder.status === 'shipped' &&
                        'Seu pedido está a caminho! Você receberá em breve.'}
                      {foundOrder.status === 'processing' &&
                        'Seu pedido está sendo preparado para envio. Acompanhe aqui o progresso.'}
                      {foundOrder.status === 'pending' &&
                        'Seu pedido foi recebido e está aguardando processamento.'}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 space-y-4 animate-slide-in-up">
                  <Package className="w-16 h-16 mx-auto text-muted-foreground opacity-50" />
                  <h2 className="text-2xl font-bold text-foreground">Pedido não encontrado</h2>
                  <p className="text-muted-foreground">
                    Não conseguimos encontrar um pedido com o número "{searchTerm}". Verifique se digitou corretamente.
                  </p>
                </div>
              )}

              <button
                onClick={() => {
                  setSearched(false);
                  setSearchTerm('');
                  setFoundOrder(null);
                }}
                className="w-full py-2 text-primary font-medium hover:bg-primary/10 rounded-lg transition-colors"
              >
                Nova Busca
              </button>
            </div>
          )}

          {/* Demo Orders */}
          {!searched && (
            <div className="space-y-6">
              <div className="bg-secondary p-6 rounded-lg border border-border">
                <p className="text-sm text-muted-foreground mb-4">
                  Números de pedidos de demonstração para testar:
                </p>
                <div className="flex flex-wrap gap-2">
                  {mockOrders.map((order) => (
                    <button
                      key={order.id}
                      onClick={() => {
                        setSearchTerm(order.id);
                        setFoundOrder(order);
                        setSearched(true);
                      }}
                      className="px-4 py-2 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-accent hover:text-accent-foreground transition-all"
                    >
                      {order.id}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
