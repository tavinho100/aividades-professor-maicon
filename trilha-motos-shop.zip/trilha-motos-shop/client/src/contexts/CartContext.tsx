import React, { createContext, useContext, useState, ReactNode } from 'react';
import { CartItem, Motorcycle } from '@/lib/motorcycles';

interface CartContextType {
  items: CartItem[];
  addToCart: (motorcycle: Motorcycle, quantity: number) => void;
  removeFromCart: (motorcycleId: number) => void;
  updateQuantity: (motorcycleId: number, quantity: number) => void;
  clearCart: () => void;
  getTotalPrice: () => number;
  getTotalItems: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const addToCart = (motorcycle: Motorcycle, quantity: number) => {
    setItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.motorcycle.id === motorcycle.id);
      if (existingItem) {
        return prevItems.map((item) =>
          item.motorcycle.id === motorcycle.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prevItems, { motorcycle, quantity }];
    });
  };

  const removeFromCart = (motorcycleId: number) => {
    setItems((prevItems) => prevItems.filter((item) => item.motorcycle.id !== motorcycleId));
  };

  const updateQuantity = (motorcycleId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(motorcycleId);
      return;
    }
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.motorcycle.id === motorcycleId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  const getTotalPrice = () => {
    return items.reduce((total, item) => total + item.motorcycle.price * item.quantity, 0);
  };

  const getTotalItems = () => {
    return items.reduce((total, item) => total + item.quantity, 0);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getTotalPrice,
        getTotalItems,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
