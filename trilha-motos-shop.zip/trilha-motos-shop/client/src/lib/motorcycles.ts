export interface Motorcycle {
  id: number;
  brand: string;
  model: string;
  year: number;
  price: number;
  description: string;
  image: string;
  specs: {
    engine: string;
    transmission: string;
    fuelCapacity: string;
    weight: string;
    maxPower: string;
  };
}

export interface CartItem {
  motorcycle: Motorcycle;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  totalPrice: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  createdAt: Date;
}

export const motorcycles: Motorcycle[] = [
  {
    id: 1,
    brand: 'Yamaha',
    model: 'WR450F',
    year: 2023,
    price: 28000,
    description: 'Ideal para trilhas, com motor potente e suspensão de alta performance. Perfeita para pilotos que buscam desempenho extremo em terrenos desafiadores.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/moto-yamaha-wr450f-YEvBjacwRzxP9CiVfAqC3x.webp',
    specs: {
      engine: '450cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '7.3L',
      weight: '147 kg',
      maxPower: '54 hp'
    }
  },
  {
    id: 2,
    brand: 'Honda',
    model: 'CRF 250R',
    year: 2023,
    price: 22500,
    description: 'Motos de desempenho superior para trilhas e competições. Confiável, ágil e responsiva, ideal para pilotos intermediários.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/moto-honda-crf-250r-6JC8HcvTppg6btNgHFsVUX.webp',
    specs: {
      engine: '250cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '6.2L',
      weight: '130 kg',
      maxPower: '28 hp'
    }
  },
  {
    id: 3,
    brand: 'KTM',
    model: '350 EXC-F',
    year: 2023,
    price: 32000,
    description: 'Alta performance, ideal para pilotos avançados que buscam potência e precisão em trilhas extremas.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/moto-yamaha-wr450f-YEvBjacwRzxP9CiVfAqC3x.webp',
    specs: {
      engine: '350cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '8.0L',
      weight: '148 kg',
      maxPower: '48 hp'
    }
  },
  {
    id: 4,
    brand: 'Suzuki',
    model: 'RM-Z250',
    year: 2023,
    price: 19900,
    description: 'Moto ágil, ideal para terrenos acidentados. Excelente relação custo-benefício para iniciantes e pilotos intermediários.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/moto-honda-crf-250r-6JC8HcvTppg6btNgHFsVUX.webp',
    specs: {
      engine: '250cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '6.0L',
      weight: '125 kg',
      maxPower: '27 hp'
    }
  },
  {
    id: 5,
    brand: 'Honda',
    model: 'CRF 450R',
    year: 2024,
    price: 35000,
    description: 'Moto de alta performance com motor potente e suspensão de classe mundial. Ideal para pilotos profissionais que buscam dominar trilhas extremas.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/crf-450r-red-gLimAYfo8xxKbK29iHHKiG.webp',
    specs: {
      engine: '450cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '7.7L',
      weight: '152 kg',
      maxPower: '56 hp'
    }
  },
  {
    id: 6,
    brand: 'Honda',
    model: 'CRF 150R',
    year: 2024,
    price: 14500,
    description: 'Moto leve e ágil, perfeita para iniciantes e pilotos jovens. Excelente para aprender técnicas de trilha com segurança.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/crf-150r-yellow-nkGsDPNxB2doG9AYkZXMRx.webp',
    specs: {
      engine: '150cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '5.0L',
      weight: '110 kg',
      maxPower: '18 hp'
    }
  },
  {
    id: 7,
    brand: 'Honda',
    model: 'CRF 300R',
    year: 2024,
    price: 26000,
    description: 'Versão intermediária com excelente equilíbrio entre potência e controle. Ideal para pilotos que buscam evolução contínua.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/crf-300r-orange-VRvdv9CsE4f3zVM5cMKcTg.webp',
    specs: {
      engine: '300cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '6.5L',
      weight: '138 kg',
      maxPower: '35 hp'
    }
  },
  {
    id: 8,
    brand: 'Honda',
    model: 'CRF 500R',
    year: 2024,
    price: 42000,
    description: 'Topo de linha com tecnologia de ponta. Motor de 500cc com potência máxima, suspensão ajustável e freios de carbono.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663388066672/jVb8YVtnCwYeZAHkgpnhpP/crf-500r-black-dH9MvPC62JR34VMEJoTMsh.webp',
    specs: {
      engine: '500cc 4-Stroke',
      transmission: 'Manual',
      fuelCapacity: '8.5L',
      weight: '158 kg',
      maxPower: '62 hp'
    }
  }
];
