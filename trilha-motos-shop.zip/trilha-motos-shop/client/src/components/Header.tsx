import { useCart } from '@/contexts/CartContext';
import { ShoppingCart, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'wouter';

export default function Header() {
  const { getTotalItems } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const totalItems = getTotalItems();

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border">
      <div className="container flex items-center justify-between h-20">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="display-title text-2xl md:text-3xl text-primary group-hover:glow-text transition-all duration-300">
            TRILHA
          </div>
          <div className="text-xs font-bold text-accent uppercase tracking-widest">
            Motos
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
            Início
          </Link>
          <Link href="/motos" className="text-foreground hover:text-primary transition-colors font-medium">
            Catálogo
          </Link>
          <Link href="/buscar" className="text-foreground hover:text-primary transition-colors font-medium">
            Buscar
          </Link>
          <Link href="/pedidos" className="text-foreground hover:text-primary transition-colors font-medium">
            Pedidos
          </Link>
        </nav>

        {/* Cart Button */}
        <div className="flex items-center gap-4">
          <Link href="/carrinho" className="relative group">
            <div className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <ShoppingCart className="w-6 h-6 text-primary group-hover:text-accent transition-colors" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center animate-glow-pulse">
                  {totalItems}
                </span>
              )}
            </div>
          </Link>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-secondary transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-primary" />
            ) : (
              <Menu className="w-6 h-6 text-primary" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <nav className="md:hidden bg-secondary border-t border-border py-4 px-4 space-y-3 animate-slide-in-down">
          <Link href="/" className="block text-foreground hover:text-primary transition-colors font-medium py-2">
            Início
          </Link>
          <Link href="/motos" className="block text-foreground hover:text-primary transition-colors font-medium py-2">
            Catálogo
          </Link>
          <Link href="/buscar" className="block text-foreground hover:text-primary transition-colors font-medium py-2">
            Buscar
          </Link>
          <Link href="/pedidos" className="block text-foreground hover:text-primary transition-colors font-medium py-2">
            Pedidos
          </Link>
        </nav>
      )}
    </header>
  );
}
