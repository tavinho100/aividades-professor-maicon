import { Motorcycle } from '@/lib/motorcycles';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';

interface MotorcycleCardProps {
  motorcycle: Motorcycle;
}

export default function MotorcycleCard({ motorcycle }: MotorcycleCardProps) {
  return (
    <Link href={`/moto/${motorcycle.id}`}>
      <div className="group cursor-pointer bg-card rounded-lg overflow-hidden border border-border hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/20">
        {/* Image Container */}
        <div className="relative overflow-hidden bg-secondary h-64 md:h-72">
          <img
            src={motorcycle.image}
            alt={`${motorcycle.brand} ${motorcycle.model}`}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Brand & Model */}
          <div>
            <p className="text-xs font-bold text-accent uppercase tracking-widest mb-1">
              {motorcycle.brand}
            </p>
            <h3 className="text-xl md:text-2xl font-bold text-foreground group-hover:text-primary transition-colors">
              {motorcycle.model}
            </h3>
            <p className="text-xs text-muted-foreground mt-1">{motorcycle.year}</p>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-2">
            {motorcycle.description}
          </p>

          {/* Price & CTA */}
          <div className="flex items-end justify-between pt-4 border-t border-border">
            <div>
              <p className="text-xs text-muted-foreground mb-1">A partir de</p>
              <p className="price-text text-2xl text-primary">
                R$ {motorcycle.price.toLocaleString('pt-BR')}
              </p>
            </div>
            <div className="p-2 rounded-lg bg-primary text-primary-foreground group-hover:bg-accent group-hover:text-accent-foreground transition-all duration-300 transform group-hover:translate-x-1">
              <ArrowRight className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
